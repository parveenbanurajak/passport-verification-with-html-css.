-// $(".input_text").focus(function(){
//     $(this).prev('.fa').addclass('glowIcon')
// })
// $(".input_text").focusout(function(){
//     $(this).prev('.fa').removeclass('glowIcon')
// })

// let hv=document.getElementById("login_button")s
function kk(){
let e=document.getElementById("login_button").value;
let n=document.getElementById("login_button").value;
if(username=='' && password=='')
}
